import csv
import math
import shutil
import sys
from pathlib import Path

RUNS = {'SRR12774931', 'SRR12774932'}

def read(path):
    with open(path, newline='') as f:
        return list(csv.DictReader(f, delimiter='\t'))

def manifest():
    rows = read('results/metadata/validation_fastq_manifest.tsv')
    if len(rows) != 2 or {r['run_accession'] for r in rows} != RUNS:
        raise ValueError('Expected exactly one FASTQ for each of the two CHO runs')
    print('run_accession\tfastq_bytes\tfastq_structure\tfastq_role')
    for r in rows:
        if r['omics'] != 'ATAC-seq' or any(r[k] != 'SINGLE' for k in ('processing_layout', 'fastq_structure', 'fastq_role')):
            raise ValueError('Unexpected modality or FASTQ structure: ' + r['run_accession'])
        if int(r['fastq_bytes']) <= 0:
            raise ValueError('Invalid FASTQ size')
        print('\t'.join(r[k] for k in ('run_accession','fastq_bytes','fastq_structure','fastq_role')))

def tss(run):
    if run not in RUNS:
        raise ValueError('Unexpected run')
    qc = Path('results/atacseq/qc') / run
    for name in ('tss_enrichment_summary.tsv','tss_profile.tsv'):
        rows = read(qc / name)
        if not rows:
            raise ValueError('Empty TSS output: ' + name)
        for row in rows:
            for key, value in row.items():
                if value is None or not value.strip():
                    raise ValueError('Missing field in TSS output: ' + key)
                try:
                    number = float(value)
                except ValueError:
                    continue
                if not math.isfinite(number):
                    raise ValueError('Nonfinite TSS value: ' + key)
    print('TSS files are nonempty and contain no missing/nonfinite numeric values; no biological threshold applied.')

def clean(run, work, scratch):
    root = Path(work).resolve()
    tmp = Path(scratch).resolve()
    if run not in RUNS or root.parent != tmp or Path.cwd().resolve() != root or not root.name.startswith('atac_bulk_'):
        raise ValueError('Scratch cleanup scope mismatch')
    for relative in ('data/raw/fastq','results/preprocessing/fastp','results/atacseq/bowtie2','results/atacseq/filtered_bam'):
        path = root / relative / run
        if path.is_symlink() or root not in path.resolve().parents:
            raise ValueError('Unsafe scratch path')
        if path.exists():
            shutil.rmtree(path)

if __name__ == '__main__':
    if sys.argv[1] == 'manifest': manifest()
    elif sys.argv[1] == 'tss': tss(sys.argv[2])
    elif sys.argv[1] == 'clean': clean(*sys.argv[2:])
    else: raise ValueError('Unknown operation')
